# -*- coding: utf-8 -*
import os
from pyltp import Segmentor
from gensim.models.word2vec import Word2Vec
import numpy as np
import random


# 数据读取模块
def get_comment_and_label(path):
    """
    从goodcomment.txt文件中读取评论到列表中，标签打0
    从generalcomment.txt文件中读取评论到列表中，标签打1
    从poorcomment.txt文件中读取评论到列表中，标签打2

    input：评论评论集所在目录。目录下结构：/类别/评论
    output：评论列表[[评论],[评论]...[评论]]，标签列表[[1],[2]...[1]]
    """
    for x in os.listdir(path):
        if os.path.isdir(path + x):
            print(path+x)

    cate = [path + x for x in os.listdir(path) if os.path.isdir(path + x)]  # 逐个打开文件夹，并读取评论。
    print(cate)
    comment = []
    comment_temp = ""
    labels = []

    for folder in cate:  # 用于在for循环中得到计数
        for im in os.listdir(folder):  # 返回所有匹配的文件路径列表
            # print('reading the comment:%s' % (folder + '/' + im))
            with open(folder + '/' + im, "r", encoding='utf-8-sig') as f:
                for line in f:
                    if line != "\n":
                        comment_temp += line.strip()
                    else:
                        if comment_temp != "":
                            comment.append(comment_temp)
                            if im == "GoodComment.txt":
                                labels.append([0])
                            elif im == "GeneralComment.txt":
                                labels.append([1])
                            elif im == "PoorComment.txt":
                                labels.append([2])
                        comment_temp = ""

    return comment, labels


# 数据打乱模块
def get_shuffled(comment_list, label_list):
    """
    # 将数据顺序随机打乱
    :param comment_list: 评论列表
    :param label_list: 标签列表
    :return: 打乱顺序后的评论列表，打乱顺序后的标签列表
    """
    comment_shuffled = []
    label_shuffled = []
    num_list_len = len(comment_list)
    seed = [i for i in range(num_list_len)]
    # print(seed)
    random.shuffle(seed)
    # print(seed)
    for i in seed:
        comment_shuffled.append(comment_list[i])
        label_shuffled.append(label_list[i])
    return comment_shuffled, label_shuffled


# 分词模块
def get_word(comment_list):
    """
    使用jieba/pyltp将三列列表中整句评论进行分词操作
    得到每个评论的分词
    :param comment_list: 评论列表:[[评论],[评论]...[评论]]
    :return: 评论分词列表:[[词，词...词],[]...[]]
    """
    # LTP_DATA_DIR = '.././LTP/ltp_data_v3.4.0'  # ltp模型目录的路径
    LTP_DATA_DIR = "/home/tea/luojie/LTP/ltp_data_v3.4.0"
    cws_model_path = os.path.join(LTP_DATA_DIR, 'cws.model')  # 分词模型路径，模型名称为`cws.model`

    comment_words = []
    segmentor = Segmentor()  # 初始化实例
    segmentor.load(cws_model_path)  # 加载模型，参数lexicon是自定义词典的文件路径
    for comment in comment_list:
        words = list(segmentor.segment(comment))
        if len(words) == 0:
            continue
        comment_words.append(words)
    segmentor.release()
    return comment_words


# 统计词频模块
def get_word_frequency(comment_words):
    """
    统计评论中每个词出现的频率，存储在字典中：字典格式：{词:次}
    :param comment_words: 分好词的评论列表[[词，词...词],[]...[]]
    :return: 字典{词：出现次数}
    """
    word_dic = {}
    for comment in comment_words:
        for word in comment:
            if word in word_dic.keys():
                word_dic[word] += 1
            else:
                word_dic[word] = 1
    return word_dic


# word2vec模块
def get_word2vec(comment_words, word_frequency):
    """
    将分词后评论列表进行word2vec操作
    得到每个评论的句向量
    评论分词中：
    不在字典中的分词用100维零矩阵->list表示
    在字典中，频数<=5的词用100维零矩阵->list表示
    在字典中，频数>5的词调用word2vec模型得到词向量->list表示
    :param comment_words: 分好词的评论列表[[词，词...词],[]...[]]，
    :param word_frequency: 词频字典{词：出现次数}
    :return: 评论的词向量列表[[vec, vec...vec]，[],[]]
    """
    comment_word2vec = []
    comment_word2vec_temp = []
    # model = Word2Vec.load('./Word2vecModel/MyModel')
    model = Word2Vec.load('/home/tea/luojie/emotion2/Word2vecModel/MyModel')
    # tea @ aic - deepserver: ~ / luojie / emotion2 / Word2vecModel

    # test=0
    # for i in comment_words:
    #     for j in i:
    #         test += 1
    # print(test)
    # test = 0

    for comment in comment_words:
        for word in comment:
            if word not in word_frequency.keys():
                comment_word2vec_temp.append(np.zeros(100, np.float32).tolist())
            elif word_frequency[word] <= 5:
                comment_word2vec_temp.append(np.zeros(100, np.float32).tolist())
            else:
                comment_word2vec_temp.append(model[word].tolist())
                # print(test)
                # test+=1
        comment_word2vec.append(comment_word2vec_temp)
        comment_word2vec_temp = []
    return comment_word2vec


# 排序模块
def get_sorted(comment_word2vec, comment_labels):
    """
    将输入进来的评论、标签列表
    按照评论长度进行对应排序
    短句在前长句在后
    方便后续padding操作使填充字符尽量少
    :param comment_word2vec: 评论的词向量列表[[vec, vec...vec]，[],[]]，
    :param comment_labels: 标签列表[[1],[2]...[1]]
    :return:按评论长短排序的评论的词向量列表[[vec,vec...vec](vec少)，...[]，[](vec多)]，对应的标签列表[[1],[2]...[1]](和词向量对应的)
    """
    comment_temp = []
    comment_word2vec_sorted = []
    comment_labels_sorted = []
    for i in range(len(comment_word2vec)):
        comment_temp.append(comment_word2vec[i])

        comment_temp[i].append(comment_labels[i])
        # print(comment_temp[i])
        # print("________________________________________________________________________________________________________________________")
    # print(comment_temp[0])
    # print(comment_temp[0][0])
    # print(comment_temp[0][0][0])
    comment_temp.sort(key=lambda i: len(i), reverse=True)
    for i in range(len(comment_temp)):
        comment_word2vec_sorted.append(comment_temp[i][:-1])
        comment_labels_sorted.append(comment_temp[i][-1])
    return comment_word2vec_sorted, comment_labels_sorted


# padding模块
def get_padding(comment_word2vec):
    """
    对输入进来的评论列表按照输入进来的最长评论padding
    :param comment_word2vec: 待填充的评论的词向量列表[[vec,vec...vec](vec少)，...[]，[](vec多)]
    :return: 填充好的评论的词向量列表[[vec,vec...vec](vec一样多)，...[]，[](vec一样多)]
    """
    comment_word2vec_pad = comment_word2vec[:]
    max_len = len(comment_word2vec[0])
    # print(max_len)
    # print("hhhlen(comment)")
    for comment in comment_word2vec_pad:
        comment_len = len(comment)
        if comment_len < max_len:
            for i in range(max_len - comment_len):
                comment.append(np.zeros((1, 100), dtype=np.float32)[0])
    return comment_word2vec_pad


# one_hot模块
def get_one_hot(label_list, class_num):
    """
    对输入进来的标签进行one_hot离散化
    :param label_list: 原始标签序列表[[1],[2],...[3]]
    :param class_num: 分类数目
    :return: one_hot标签序列表[[1,0,0],[0,1,0],...[0,0,1]]
    """
    l = len(label_list)
    res = np.zeros((l, class_num), dtype=np.float32)
    for i in range(l):
        res[i][label_list[i][0]] = 1.
    return res


# getbatch模块
def get_batch(data_comment_word2vec, data_labels, batchsize):
    """
    yield每次返回batchsize个评论，标签，padding长度
    :param data_comment_word2vec:评论的词向量列表[[vec,vec...vec](vec少)，...[]，[](vec多)]
    :param data_labels:评论词对应one_hot标签列表[[1,0,0],[0,1,0],...[0,0,1]]
    :param batchsize:batchsize大小
    :return:yield每次返回batchsize个评论，标签，padding长度，
    """
    for i in range(len(data_comment_word2vec) // batchsize):
        pos = i * batchsize
        seq_length = []
        x = data_comment_word2vec[pos:pos + batchsize]
        x = get_padding(x)
        y = data_labels[pos:pos + batchsize]
        for j in range(batchsize):
            seq_length.append(len(x[0]))
        yield np.asarray(x, np.float32), np.asarray(y, np.float32), np.asarray(seq_length, np.int32)
    remain = len(data_comment_word2vec) % batchsize
    if remain != 0:
        seq_length = []
        x = data_comment_word2vec[-remain:]
        # x = data_comment_word2vec[-remain:]+data_comment_word2vec[:batchsize-remain]
        x = get_padding(x)
        y = data_labels[-remain:]
        # y = data_labels[-remain:] + data_labels[:batchsize - remain]
        for j in range(remain):
            seq_length.append(len(x[0]))
        yield np.asarray(x, np.float32), np.asarray(y, np.float32), np.asarray(seq_length, np.int32)


if __name__ == '__main__':
    data_path = "./Data/AllComment/"
    a, b = get_comment_and_label(data_path)
    c, d = get_shuffled(a, b)
    print(len(c), len(d))
    # e = get_word(a)
    # for i in e:
    #     print(i)

