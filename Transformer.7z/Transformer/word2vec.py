# -*- coding: utf-8 -*
from pyltp import Segmentor
from gensim.models.word2vec import Word2Vec
import os

# 使用ltp分词，gensim.models.word2vec训练词向量，保存词向量


# 获得评论数据
def get_comment(path):
    cate = [path + x for x in os.listdir(path) if os.path.isdir(path + x)]  # 逐个打开文件夹，并读取评论。
    # print(cate)
    comment = []
    comment_temp = ""
    for folder in cate:  # 用于在for循环中得到计数
        for im in os.listdir(folder):  # 返回所有匹配的文件路径列表
            print('reading the comment:%s' % (folder + '/' + im))
            with open(folder + '/' + im, "r", encoding='UTF-8-sig') as f:
                for line in f:
                    if line != "\n":
                        # print(line.strip())
                        comment_temp += line.strip()
                    else:
                        if comment_temp != "":
                            comment.append(comment_temp)
                            comment_temp = ""

    return comment


# 进行分词
def get_word(comment_list):
    LTP_DATA_DIR = '.././LTP/ltp_data_v3.4.0'  # ltp模型目录的路径
    cws_model_path = os.path.join(LTP_DATA_DIR, 'cws.model')  # 分词模型路径，模型名称为`cws.model`
    comment_words = []
    segmentor = Segmentor()  # 初始化实例
    segmentor.load(cws_model_path)  # 加载模型
    for comment in comment_list:
        words = list(segmentor.segment(comment))
        comment_words.append(words)
    segmentor.release()
    return comment_words


# 训练词向量
def tran_vec(b):
    model = Word2Vec(b, sg=1, size=100, window=5, min_count=5, negative=3, sample=0.001, hs=1, workers=4)
    model.train(b, total_examples=model.corpus_count, epochs=model.iter)
    vec_path = "Word2vecModel"
    if not os.path.exists(vec_path):
        os.mkdir(vec_path)
    model.wv.save_word2vec_format("./Word2vecModel/seg_with_dict_w2c_done", binary=False)
    model.wv.save_word2vec_format("./Word2vecModel/seg_with_dict_w2c_done.bin", binary=True)

    model.save('./Word2vecModel/MyModel')
    # # print("finished")
    # # model.save_word2vec_format('./Word2vecModel/mymodel.txt',binary = False)
    # # model.save_word2vec_format('/Word2vecModel/mymodel.bin.gz',binary = True)
    # #model = Word2vecModel.Word2Vec(sentences=sentences, size=300, hs=1)
    # model.wv.save_word2vec_format("./Word2vecModel/seg_with_dict_w2c_done",binary=False)
    # model.wv.save_word2vec_format("./Word2vecModel/seg_with_dict_w2c_done.bin",binary=True)
    model = Word2Vec.load('./Word2vecModel/MyModel')

    # print(model["二手"])
    # print(type(model["二手"]))


if __name__ == '__main__':
    data_path = "./Data/AllComment/"
    # read_data(data_path)
    comment = get_comment(data_path)
    print(comment[:10])
    seg_comment = get_word(comment)
    # model = Word2Vec()
    tran_vec(seg_comment)



