"""
本文件调用data_process.py文件中函数接口获取需要的数据
在本文件中构建深度学习模型进行京东评论的情感分析
本版本直接将评论padding好的word2vec输入进lstm
输出使用softmax做3分类情感[[好][中][差]]。后续可以细分粒度在softmax增加相应维度
"""
import tensorflow as tf
import numpy as np
import data_process as dp
import model_utils as mu
import math


class_num = 3
lr = 0.001
epoch = 20
isTrain = 1
batch_size = 64
max_model_num = 5
# feature_num = 300
hidden_size = 100
hiddenlayers=3
numhead=4

# reludropout=0.1
# attentiondropout= 0.1
size_per_head = 64
optimizer_type = 1

#训练集路径
data_path = "./Data/AllComment/"

# 从文件读取评论并获取标签
comment, labels = dp.get_comment_and_label(data_path)
# print(comment[:10])

# 对评论和标签进行打乱
comment, labels = dp.get_shuffled(comment, labels)

# 分训练集测试集验证集
num_comment_len = len(comment)

vl = int(num_comment_len*0.8)
tl = int(num_comment_len*0.9)

comment_train = comment[:vl]
label_train = labels[:vl]

comment_val = comment[vl:tl]
label_val = labels[vl:tl]

comment_test = comment[tl:]
label_test = labels[tl:]

# with open("val_.txt",)
train_remainder = len(comment_train) % batch_size
valid_remainder = len(comment_val) % batch_size
test_remainder = len(comment_test) % batch_size

# 补齐长度
comment_train = comment_train + comment_train[0:batch_size-train_remainder]
label_train = label_train + label_train[0:batch_size-train_remainder]

comment_val = comment_val + comment_val[0:batch_size-valid_remainder]
label_val = label_val + label_val[0:batch_size-valid_remainder]

comment_test = comment_test + comment_test[0:batch_size-test_remainder]
label_test = label_test + label_test[0:batch_size-test_remainder]


def data_to_net(comment, label):
    # 对评论进行分词
    comment_words = dp.get_word(comment)

    # 获取词频
    word_frequency_dic = dp.get_word_frequency(comment_words)

    # 获取词向量
    comment_word2vec_dic = dp.get_word2vec(comment_words, word_frequency_dic)

    # 将评论词ID和对应标签排序按照从大到小
    comment_ID_sorted, comment_labels_sorted = dp.get_sorted(comment_word2vec_dic, label)

    # 标签转换one_hot
    comment_labels_sorted_ont_hot = dp.get_one_hot(comment_labels_sorted, class_num)
    return comment_ID_sorted, comment_labels_sorted_ont_hot


x_train, y_train = data_to_net(comment_train, label_train)
x_val, y_val = data_to_net(comment_val, label_val)
x_test, y_test = data_to_net(comment_test, label_test)


def Position_Embedding(inputs, seq_lenth,position_size):
    # batch_size,seq_len = tf.shape(inputs)[0],tf.shape(inputs)[1]
    batch_size, seq_len = tf.shape(inputs)[0], np.float32(seq_lenth)
    position_j = 1. / tf.pow(10000.,2 * tf.range(position_size / 2, dtype=tf.float32) / position_size)
    position_j = tf.expand_dims(position_j, 0)
    position_i = tf.range(tf.cast(seq_len, tf.float32), dtype=tf.float32)
    position_i = tf.expand_dims(position_i, 1)
    position_ij = tf.matmul(position_i, position_j)
    position_ij = tf.concat([tf.cos(position_ij), tf.sin(position_ij)], 1)
    position_embedding = tf.expand_dims(position_ij, 0) \
                         + tf.zeros((batch_size, seq_len, position_size))
    return position_embedding

def get_position_encoding(length, hidden_size, min_timescale=1.0, max_timescale=1.0e4):
  """Return positional encoding.

  Calculates the position encoding as a mix of sine and cosine functions with
  geometrically increasing wavelengths.
  Defined and formulized in Attention is All You Need, section 3.5.

  Args:
    length: Sequence length.
    hidden_size: Size of the
    min_timescale: Minimum scale that will be applied at each position
    max_timescale: Maximum scale that will be applied at each position

  Returns:
    Tensor with shape [length, hidden_size]
  """
  position = np.float32(np.arange(length))
  num_timescales = hidden_size // 2
  log_timescale_increment = (
      math.log(float(max_timescale) / float(min_timescale)) /
      (np.float32(num_timescales) - 1))
  inv_timescales = min_timescale * np.exp(
      np.float32(np.arange(num_timescales)) * -log_timescale_increment)
  scaled_time = np.expand_dims(position, 1) * np.expand_dims(inv_timescales, 0)
  signal = np.concatenate([np.sin(scaled_time), np.cos(scaled_time)], axis=1)
  return signal


def Attention(query,nb_head, size_per_head):
    #对Q、K、V分别作线性映射
    Q = tf.layers.dense(query, nb_head * size_per_head)
    # print(11,Q)  # shape=(10, ?, 256) [batch_size,seq_len,numhead*size_per_head]
    Q = tf.reshape(Q, (-1, tf.shape(Q)[1], nb_head, size_per_head))  # [batch_size,seq_len,numhead,hiddensize]
    # print(22,Q)  # shape=(?, ?, 4, 64), [batchsize,seq_len,numhead,size_per_head]
    Q = tf.transpose(Q, [0, 2, 1, 3])  # [batch_size,numhead,seq_len,size_per_head]
    # print(33,Q)  # shape=(?, 4, ?, 64)  [batch_size,numhead,seq_len,size_per_head]

    K = tf.layers.dense(query, nb_head * size_per_head)
    K = tf.reshape(K, (-1, tf.shape(K)[1], nb_head, size_per_head))
    K = tf.transpose(K, [0, 2, 1, 3])
    # print("*******k**********",K)

    V = tf.layers.dense(query, nb_head * size_per_head)
    V = tf.reshape(V, (-1, tf.shape(V)[1], nb_head, size_per_head))
    V = tf.transpose(V, [0, 2, 1, 3])
    #计算内积，然后mask，然后softmax
    # print("%"*20,Q,K)
    # q = Q
    # k = K
    A = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(float(size_per_head)) # [batch_size,numhead,seq_len,hiddensize]
    # print(44, A)  # shape=(?, 4, ?, ?)  [batch_size,numhead,seq_len,seq_len]
    A = tf.transpose(A, [0, 3, 2, 1])  # [batch_size,numhead,seq_len,size_per_head] -->[batch_size,size_per_head,seq_len,numhead]
    # print(55, A)  # shape=(?, ?, ?, 4)  [batch_size,seq_len,seq_len,numhead]
    A = tf.transpose(A, [0, 3, 2, 1])
    # print(66,A)  # shape=(?, 4, ?, ?)  [batch_size,numhead,seq_len,seq_len]
    A = tf.nn.softmax(A)
    #输出并mask
    # A:[batch_size,hiddensize,seq_len,numhead]  V:[batch_size,numhead,seq_len,hiddensize]
    O = tf.matmul(A, V)  # [batch_size,numhead,seq_len,seq_len]x[batch_size,numhead,seq_len,size_per_head]
    # print(77,O)  # shape=(?, 4, ?, 64), [batch_size,numhead,seq_len,size_per_head]
    O = tf.transpose(O, [0, 2, 1, 3])
    # print(88,O)  # shape=(?, ?, 4, 64)  [batch_size,seq_len,numhead,size_per_head]
    O = tf.reshape(O, (-1, tf.shape(O)[1], nb_head * size_per_head))
    # print(99,O)  # shape=(?, ?, 1200) [batch_size,seq_len,numhead*size_per_head]
    return O


def normalize(inputs,
              epsilon=1e-8,
              scope="ln",
              reuse=None):
    '''Applies layer normalization.

    Args:
      inputs: A tensor with 2 or more dimensions, where the first dimension has
        `batch_size`.
      epsilon: A floating number. A very small number for preventing ZeroDivision Error.
      scope: Optional scope for `variable_scope`.
      reuse: Boolean, whether to reuse the weights of a previous layer
        by the same name.

    Returns:
      A tensor with the same shape and data dtype as `inputs`.
    '''
    with tf.variable_scope(scope, reuse=reuse):
        inputs_shape = inputs.get_shape()
        params_shape = inputs_shape[-1:]

        mean, variance = tf.nn.moments(inputs, [-1], keep_dims=True)
        beta = tf.Variable(tf.zeros(params_shape))
        gamma = tf.Variable(tf.ones(params_shape))
        normalized = (inputs - mean) / ((variance + epsilon) ** (.5))
        outputs = gamma * normalized + beta
    return outputs


# 模型
graph = tf.Graph()
with graph.as_default():
    # define the global step of the graph
    global_step = tf.train.create_global_step(graph)
    X = tf.placeholder(shape=[batch_size, None, hidden_size], dtype=tf.float32, name="word_vec")
    Y = tf.placeholder(tf.int32, [None, class_num])
    # lear_rate = tf.placeholder(dtype=tf.float32, name="learning_rate")
    # [length, hidden_size]
    pos = tf.placeholder(tf.float32, [None, hidden_size])
    # seq_lenth = tf.placeholder(tf.int32)

    # 输入数据+位置编码
    encoder_inputs = X + pos
    # print("*****encoder_inputs_3****", encoder_inputs)  # shape=(10, ?, 100)

    with tf.variable_scope("Multi_Head_Attention"):
        encoder_outputs_1 = Attention(encoder_inputs, numhead, size_per_head)
        # print("*****encoder_outputs_1****", encoder_outputs_1)  # shape=(?, ?, 1200)
        # 将维度变为与输入数据一样的维度 [batch_size,seq_len,numhead*size_per_head]-->[batch_size,seq_len,hiddensize]
        encoder_outputs_2 = tf.layers.dense(encoder_outputs_1, hidden_size)
        # print("****encoder_outputs_2*****:", encoder_outputs_2)
    with tf.variable_scope("residual"):
        encoder_residual_outputs = encoder_outputs_2 + encoder_inputs
        # print("encoder_residual_outputs", encoder_residual_outputs)
    with tf.variable_scope("Normalize"):
        # Normalize
        encoder_normalize_outputs = normalize(encoder_residual_outputs)
        # print("encoder_normalize_outputs", encoder_normalize_outputs)

    with tf.variable_scope("feedforward"):
        # 一维卷积
        cnn_outputs = tf.layers.conv1d(encoder_normalize_outputs, hidden_size, kernel_size=1, activation=tf.nn.relu)
        # Residual connection
        cnn_residual_outputs = cnn_outputs + encoder_outputs_2
        # Normalize
        feed_normalize_outputs = normalize(cnn_residual_outputs)

        # print("feed_normalize_outputs", feed_normalize_outputs)

    with tf.variable_scope("full_layer"):
        # logsts_input = tf.reshape(feed_normalize_outputs, [batch_size, -1])
        logsts_input = tf.reduce_sum(feed_normalize_outputs, axis=1)
        logits = tf.layers.dense(inputs=logsts_input,
                                 units=class_num,
                                 activation=None,
                                 kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),
                                 )

    loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=logits, labels=Y))

    optimizer_collection = {0: tf.train.GradientDescentOptimizer(lr),
                            1: tf.train.AdamOptimizer(lr),
                            2: tf.train.RMSPropOptimizer(lr)}
    # Using the optimizer defined by optimizer_type
    optimizer = optimizer_collection[optimizer_type]

    # compute gradient
    gradients = optimizer.compute_gradients(loss)
    # apply gradient clipping to prevent gradient explosion
    capped_gradients = [(tf.clip_by_norm(grad, 5.), var) for grad, var in gradients if grad is not None]
    # update the RNN
    opt = optimizer.apply_gradients(capped_gradients, global_step=global_step)

    # opt = tf.train.GradientDescentOptimizer(lr).minimize(loss)
    # opt = tf.train.AdamOptimizer(lr).minimize(loss)
    summary_loss = tf.summary.scalar('loss', loss)
    true = tf.argmax(Y, axis=1)
    pred_softmax = tf.nn.softmax(logits)
    pred = tf.argmax(pred_softmax, axis=1)
    correct_prediction = tf.equal(tf.cast(pred, tf.int64), true)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    summary_acc = tf.summary.scalar('acc', accuracy)

with tf.Session(graph=graph) as sess:
    # define summary file writer
    writer = tf.summary.FileWriter("./summary/visualization/", graph=graph)
    merged = tf.summary.merge_all()
    saver = tf.train.Saver(max_to_keep=max_model_num)
    if isTrain == 1:
        init = tf.global_variables_initializer()
        sess.run(init)
        # saver.restore()
        # saver = tf.train.Saver()
        # model_file = tf.train.latest_checkpoint('../server/ckpt/')
        # saver.restore(sess, model_file)
        # step = 1
        for epc in range(epoch):
            for x1, y1, seq_length in dp.get_batch(x_train, y_train, batch_size):
                # print(333, x1.shape)
                # print(233355, seq_length)
                seq_len_tran = x1.shape[1]
                step = tf.train.global_step(sess, global_step)
                _, loss_, s_m, acc = sess.run([opt, loss, merged, accuracy], {X: x1,
                                                                              Y: y1,
                                                                              pos:get_position_encoding(seq_len_tran,hidden_size)
                                                                              # pos:Position_Embedding(x1, seq_len_tran,hidden_size)
                                                                              })
                writer.add_summary(s_m, global_step=step)
                if step % 50 == 0:
                    print("训练Step:{:>5},loss:{:>7.4f},Accuracy:{:>7.2%}".format(step, loss_, acc))
                    error = 0.0
                    vali_loss = []
                    acc_val_list = []
                    for x2, y2, seq_length2 in dp.get_batch(x_val, y_val, batch_size):
                        # print(444, x2.shape)
                        seq_val = x2.shape[1]
                        loss_val, acc_val = sess.run([loss, accuracy], {X: x2,
                                                                        Y: y2,
                                                                        pos: get_position_encoding(seq_val, hidden_size)
                                                                        # pos: Position_Embedding(x2, seq_val,
                                                                        #                         hidden_size)
                                                                        })
                        vali_loss.append(loss_val)
                        acc_val_list.append(acc_val)
                    loss_v = sum(vali_loss) / len(vali_loss)
                    acc_v = sum(acc_val_list) / len(acc_val_list)
                    print("验证Step:{:>5},loss:{:>7.4f},Accuracy:{:>7.2%}".format(step, loss_v, acc_v))
                if step % 500 == 0:
                    saver.save(sess, save_path="./ckpt/model.ckpt", global_step=step)
                step += 1
        error = 0.0
        vali_loss = []
        acc_test_list = []
        for x3, y3, seq_length3 in dp.get_batch(x_test, y_test, batch_size):
            seq_test = x3.shape[1]
            loss_test, acc_test = sess.run([loss, accuracy], {X: x3,
                                                              Y: y3,
                                                              pos: get_position_encoding(seq_test, hidden_size)
                                                              # pos: Position_Embedding(x3, seq_test,
                                                              #                         hidden_size)
                                                              })
            vali_loss.append(loss_test)
            acc_test_list.append(acc_test)
        loss_t = sum(vali_loss) / len(vali_loss)
        acc_t = sum(acc_test_list) / len(acc_test_list)
        print("测试集loss:{:>7.4f},Accuracy:{:>7.2%}".format(loss_t, acc_t))
        print("Training Finished")
    elif isTrain == 0:
        # 加载模型，进行测试
        pass
